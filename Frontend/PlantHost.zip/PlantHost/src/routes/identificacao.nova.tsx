import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Image as ImageIcon, ListChecks } from "lucide-react";
import { AppLayout } from "@/components/planthost/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useIdentification, setIdentification } from "@/lib/planthost/store";

export const Route = createFileRoute("/identificacao/nova")({
  head: () => ({
    meta: [
      { title: "Nova identificação — PlantHost AI" },
      { name: "description", content: "Informe local, data, observador e o modo de identificação da planta." },
      { property: "og:title", content: "Nova identificação — PlantHost AI" },
      { property: "og:description", content: "Inicie uma nova análise de espécie vegetal do semiárido." },
    ],
  }),
  component: NovaIdentificacao,
});

function NovaIdentificacao() {
  const state = useIdentification();
  const navigate = useNavigate();

  const modes = [
    { id: "caracteristicas" as const, label: "Características botânicas", icon: ListChecks, enabled: true },
    { id: "imagem" as const, label: "Imagem + características", icon: ImageIcon, enabled: false },
  ];

  return (
    <AppLayout
      step={2}
      backTo="/"
      title="Nova identificação"
      description="Informe as características observadas na planta para gerar uma classificação."
    >
      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <Card className="shadow-card">
          <CardContent className="space-y-5 p-6">
            <div>
              <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Modo de identificação</p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {modes.map((m) => {
                  const active = state.mode === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      disabled={!m.enabled}
                      onClick={() => setIdentification({ mode: m.id })}
                      className={`flex items-start gap-3 rounded-lg border p-4 text-left transition-colors ${
                        active ? "border-primary bg-primary/5" : "border-border hover:bg-secondary/50"
                      } disabled:cursor-not-allowed disabled:opacity-50`}
                    >
                      <span
                        className={`mt-0.5 grid size-4 place-items-center rounded-full border ${
                          active ? "border-primary" : "border-muted-foreground/50"
                        }`}
                      >
                        {active && <span className="size-2 rounded-full bg-primary" />}
                      </span>
                      <span>
                        <span className="flex items-center gap-2 text-sm font-medium">
                          <m.icon className="size-4 text-primary" /> {m.label}
                        </span>
                        {!m.enabled && (
                          <span className="mt-1 block text-xs text-muted-foreground">Indisponível neste MVP</span>
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-4 border-t border-border pt-5">
              <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Informações básicas</p>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="loc">Localização da observação</Label>
                  <Input
                    id="loc"
                    placeholder="Ex.: Petrolina — PE"
                    value={state.location}
                    onChange={(e) => setIdentification({ location: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="data">Data da observação</Label>
                  <Input
                    id="data"
                    type="date"
                    value={state.date}
                    onChange={(e) => setIdentification({ date: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="obs">Observador</Label>
                  <Input
                    id="obs"
                    placeholder="Nome do observador"
                    value={state.observer}
                    onChange={(e) => setIdentification({ observer: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <Button className="w-full sm:w-auto" onClick={() => navigate({ to: "/identificacao/caracteristicas" })}>
              Continuar <ArrowRight className="size-4" />
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardContent className="p-6 text-sm text-muted-foreground">
            <p className="text-xs font-medium uppercase tracking-widest">Como funciona</p>
            <ol className="mt-4 space-y-3">
              {[
                "As características botânicas informadas compõem o vetor de entrada.",
                "O classificador retorna a espécie provável e a confiança.",
                "O registro como hospedeira é consultado na base de referência.",
                "As fontes permanecem associadas a cada informação.",
              ].map((t, i) => (
                <li key={t} className="flex gap-3">
                  <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-primary/10 font-mono text-[11px] text-primary">
                    {i + 1}
                  </span>
                  {t}
                </li>
              ))}
            </ol>
            <p className="mt-5 rounded-md border border-warning/40 bg-warning/10 p-3 text-xs text-foreground">
              Quando não houver informação disponível, o sistema exibe “Não informado”. Nenhum dado científico ou métrica
              é inventado.
            </p>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
