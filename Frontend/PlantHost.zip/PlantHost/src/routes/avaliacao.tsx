import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AlertTriangle, Grid3X3, LineChart } from "lucide-react";
import { AppLayout } from "@/components/planthost/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { MODEL_EVALUATIONS } from "@/lib/planthost/data";

export const Route = createFileRoute("/avaliacao")({
  head: () => ({
    meta: [
      { title: "Avaliação dos modelos — PlantHost AI" },
      {
        name: "description",
        content: "Comparação experimental de Decision Tree, Random Forest, SVM e KNN — métricas pendentes de execução.",
      },
      { property: "og:title", content: "Avaliação dos modelos — PlantHost AI" },
      { property: "og:description", content: "Accuracy, precision, recall, F1-score e matriz de confusão." },
    ],
  }),
  component: Avaliacao,
});

const fmt = (v: number | null) => (v === null ? "—" : v.toFixed(3));

function Avaliacao() {
  const navigate = useNavigate();
  const evaluated = MODEL_EVALUATIONS.filter((m) => m.f1_score !== null);
  const best = evaluated.sort((a, b) => (b.f1_score ?? 0) - (a.f1_score ?? 0))[0];

  return (
    <AppLayout
      step={8}
      backTo="/identificacao/evidencias"
      title="Avaliação dos modelos"
      description="Resultados experimentais dos algoritmos de classificação."
    >
      <Card className="mb-6 border-warning/40 bg-warning/10 shadow-card">
        <CardContent className="flex items-start gap-3 p-5 text-sm">
          <AlertTriangle className="mt-0.5 size-4 text-foreground/70" />
          <p>
            <strong>Dados ainda não processados.</strong> As métricas serão exibidas somente após a execução dos modelos
            com o dataset real. Nenhum valor é estimado ou inventado.
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-card">
        <CardContent className="p-2 sm:p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Modelo</TableHead>
                <TableHead className="text-right">Accuracy</TableHead>
                <TableHead className="text-right">Precision</TableHead>
                <TableHead className="text-right">Recall</TableHead>
                <TableHead className="text-right">F1-score</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {MODEL_EVALUATIONS.map((m) => (
                <TableRow key={m.model_name}>
                  <TableCell className="font-medium">{m.model_name}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.accuracy)}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.precision)}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.recall)}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.f1_score)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card className="shadow-card">
          <CardContent className="p-6">
            <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
              Gráfico comparativo
            </p>
            <div className="mt-4 grid h-56 place-items-center rounded-lg border border-dashed border-border bg-secondary/30 text-center text-sm text-muted-foreground">
              <div>
                <LineChart className="mx-auto size-6" />
                <p className="mt-2">Disponível quando houver métricas reais</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardContent className="p-6">
            <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Matriz de confusão</p>
            <div className="mt-4 grid h-56 place-items-center rounded-lg border border-dashed border-border bg-secondary/30 text-center text-sm text-muted-foreground">
              <div>
                <Grid3X3 className="mx-auto size-6" />
                <p className="mt-2">Área reservada para a matriz de confusão</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6 shadow-card">
        <CardContent className="p-6">
          <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Melhor modelo</p>
          <p className="mt-2 font-display text-xl font-semibold">
            {best ? `${best.model_name} (F1 ${fmt(best.f1_score)})` : "Aguardando avaliação com dados reais"}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Selecionado automaticamente pelo maior F1-score após a execução dos experimentos.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Button variant="outline" onClick={() => navigate({ to: "/identificacao/evidencias" })}>
              ← Voltar para evidências
            </Button>
            <Button onClick={() => navigate({ to: "/identificacao/nova" })}>Nova identificação</Button>
          </div>
        </CardContent>
      </Card>
    </AppLayout>
  );
}
