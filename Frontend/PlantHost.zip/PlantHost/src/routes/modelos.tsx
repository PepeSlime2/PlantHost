import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Brain, Check, GitBranch, Network, Users } from "lucide-react";
import { AppLayout } from "@/components/planthost/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MODELS } from "@/lib/planthost/data";

export const Route = createFileRoute("/modelos")({
  head: () => ({
    meta: [
      { title: "Modelos de Machine Learning — PlantHost AI" },
      { name: "description", content: "Algoritmos previstos para a identificação: Decision Tree, Random Forest, SVM e KNN." },
      { property: "og:title", content: "Modelos de Machine Learning — PlantHost AI" },
      { property: "og:description", content: "Pipeline e algoritmos de classificação do MVP — métricas pendentes de execução." },
    ],
  }),
  component: Modelos,
});

const MODEL_INFO: Record<(typeof MODELS)[number], { icon: typeof Brain; kind: string; desc: string }> = {
  "Decision Tree": {
    icon: GitBranch,
    kind: "Árvore de decisão",
    desc: "Modelo interpretável que combina atributos em regras sucessivas (nós e folhas), facilitando a leitura do caminho até a espécie provável.",
  },
  "Random Forest": {
    icon: Network,
    kind: "Ensemble de árvores",
    desc: "Combina várias árvores de decisão treinadas sobre amostras do dataset, reduzindo a variância de um modelo único.",
  },
  SVM: {
    icon: Brain,
    kind: "Máquina de vetores de suporte",
    desc: "Busca o hiperplano de separação com maior margem entre as classes, adequado a atributos botânicos de alta dimensão.",
  },
  KNN: {
    icon: Users,
    kind: "K-vizinhos mais próximos",
    desc: "Classifica a planta observada pela semelhança com os exemplos mais próximos do dataset — abordagem direta para comparação de atributos.",
  },
};

const PIPELINE = [
  { label: "Coleta e curadoria", desc: "Espécies e atributos das fontes de referência" },
  { label: "Pré-processamento", desc: "Padronização dos campos e dos valores não informados" },
  { label: "Feature engineering", desc: "Atributos botânicos codificados para entrada dos modelos" },
  { label: "Treinamento", desc: "Execução dos 4 algoritmos com validação do dataset" },
  { label: "Avaliação", desc: "Accuracy, precision, recall, F1-score e matriz de confusão" },
];

function Modelos() {
  return (
    <AppLayout
      title="Modelos"
      description="Algoritmos de classificação previstos para o MVP — nenhum executado com dados reais até o momento."
    >
      <div className="grid gap-4 sm:grid-cols-2">
        {MODELS.map((m) => {
          const info = MODEL_INFO[m];
          const Icon = info.icon;
          return (
            <Card key={m} className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary/10">
                    <Icon className="size-5 text-primary" />
                  </span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-display text-base font-semibold">{m}</h2>
                      <Badge variant="outline" className="border-border bg-secondary/60 text-muted-foreground">
                        Não executado
                      </Badge>
                      {m === "Random Forest" && (
                        <Badge variant="outline" className="border-primary/40 bg-primary/10 text-primary">
                          Padrão da demonstração
                        </Badge>
                      )}
                    </div>
                    <p className="mt-0.5 text-xs uppercase tracking-wide text-muted-foreground">{info.kind}</p>
                    <p className="mt-3 text-sm text-muted-foreground">{info.desc}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="mt-6 shadow-card">
        <CardContent className="p-6">
          <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Pipeline de execução</p>
          <div className="mt-5 space-y-3">
            {PIPELINE.map((p, i) => (
              <div key={p.label} className="flex items-start gap-3">
                <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full border border-border bg-secondary/60 font-mono text-[10px] text-muted-foreground">
                  {i + 1}
                </span>
                <div className="min-w-0 border-b border-dashed border-border/70 pb-3 last:border-0">
                  <p className="text-sm font-medium">{p.label}</p>
                  <p className="text-xs text-muted-foreground">{p.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="mt-6 border-warning/40 bg-warning/10 shadow-card">
        <CardContent className="flex flex-wrap items-center gap-4 p-5 text-sm">
          <span className="grid size-9 place-items-center rounded-lg bg-background/70">
            <Check className="size-4 text-foreground/70" />
          </span>
          <p className="min-w-48 flex-1 text-muted-foreground">
            A classificação usada na identificação é um comparador de atributos de demonstração, no lugar de um modelo
            treinado. Métricas reais só aparecem após a execução dos experimentos — nenhum valor é estimado ou inventado.
          </p>
          <Link
            to="/avaliacao"
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
          >
            Ver avaliação <ArrowRight className="size-4" />
          </Link>
        </CardContent>
      </Card>
    </AppLayout>
  );
}
