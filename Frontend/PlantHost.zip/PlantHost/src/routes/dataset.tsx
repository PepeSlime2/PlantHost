import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Database, Leaf, Sprout } from "lucide-react";
import { AppLayout } from "@/components/planthost/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { SPECIES } from "@/lib/planthost/data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dataset")({
  head: () => ({
    meta: [
      { title: "Dataset — PlantHost AI" },
      { name: "description", content: "Base de referência de espécies usada na identificação, com fontes associadas." },
      { property: "og:title", content: "Dataset — PlantHost AI" },
      { property: "og:description", content: "Espécies, famílias, formas de vida e registros de hospedeiro da base de referência." },
    ],
  }),
  component: Dataset,
});

const HOST_BADGE = {
  registrada: { label: "Hospedeira", className: "border-primary/40 bg-primary/10 text-primary" },
  sem_registro: { label: "Sem registro", className: "border-warning/50 bg-warning/15 text-foreground" },
  indisponivel: { label: "Indisponível", className: "border-border bg-secondary/60 text-muted-foreground" },
} as const;

function BarChart({ title, data }: { title: string; data: { label: string; value: number }[] }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  return (
    <Card className="shadow-card">
      <CardContent className="p-6">
        <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">{title}</p>
        <div className="mt-5 space-y-4">
          {data.map((d) => (
            <div key={d.label}>
              <div className="flex items-baseline justify-between gap-3 text-sm">
                <span className="truncate">{d.label}</span>
                <span className="font-mono text-xs text-muted-foreground">
                  {d.value} · {Math.round((d.value / total) * 100)}%
                </span>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full rounded-full bg-primary/80" style={{ width: `${(d.value / total) * 100}%` }} />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function Dataset() {
  const byFamily = [...new Set(SPECIES.map((s) => s.family))].map((f) => ({
    label: f,
    value: SPECIES.filter((s) => s.family === f).length,
  }));

  const byLifeForm = [...new Set(SPECIES.map((s) => s.life_form))].map((l) => ({
    label: l,
    value: SPECIES.filter((s) => s.life_form === l).length,
  }));

  const byHost = (
    [
      ["registrada", "Registradas como hospedeira"],
      ["sem_registro", "Sem registro encontrado"],
      ["indisponivel", "Informação indisponível"],
    ] as const
  ).map(([k, label]) => ({ label, value: SPECIES.filter((s) => s.host_status === k).length }));

  return (
    <AppLayout
      title="Dataset"
      description="Base de referência utilizada pela identificação — recorte de demonstração, com fontes associadas."
    >
      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { value: SPECIES.length, label: "Espécies no recorte atual" },
          { value: SPECIES.filter((s) => s.source.length).length, label: "Espécies com fonte associada" },
          { value: byFamily.length, label: "Famílias botânicas" },
        ].map((s) => (
          <Card key={s.label} className="shadow-card">
            <CardContent className="p-5">
              <p className="font-display text-3xl font-semibold text-primary">{s.value}</p>
              <p className="mt-1 text-xs text-muted-foreground">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <BarChart title="Espécies por família" data={byFamily} />
        <BarChart title="Espécies por forma de vida" data={byLifeForm} />
        <BarChart title="Registro como hospedeira" data={byHost} />
      </div>

      <Card className="mt-6 shadow-card">
        <CardContent className="p-2 sm:p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Espécie</TableHead>
                <TableHead className="hidden sm:table-cell">Família</TableHead>
                <TableHead className="hidden md:table-cell">Forma de vida</TableHead>
                <TableHead className="hidden md:table-cell">Distribuição</TableHead>
                <TableHead>Hospedeira</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {SPECIES.map((s) => (
                <TableRow key={s.id}>
                  <TableCell>
                    <span className="font-medium italic">{s.scientific_name}</span>
                    <span className="block text-xs text-muted-foreground">{s.common_name ?? "—"}</span>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">{s.family}</TableCell>
                  <TableCell className="hidden md:table-cell">{s.life_form}</TableCell>
                  <TableCell className="hidden max-w-48 truncate text-sm md:table-cell">{s.distribution}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={cn(HOST_BADGE[s.host_status].className)}>
                      {HOST_BADGE[s.host_status].label}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="mt-6 border-primary/30 bg-primary/5 shadow-card">
        <CardContent className="flex flex-wrap items-center gap-4 p-5 text-sm">
          <span className="grid size-9 place-items-center rounded-lg bg-primary/10">
            <Sprout className="size-4 text-primary" />
          </span>
          <p className="min-w-48 flex-1 text-muted-foreground">
            O recorte atual é reduzido e serve para demonstrar o fluxo do sistema. A base completa é construída a partir
            das fontes — Embrapa, Flora e Funga do Brasil e Reflora — antes da execução dos modelos.
          </p>
          <Link
            to="/modelos"
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
          >
            Ver modelos <ArrowRight className="size-4" />
          </Link>
        </CardContent>
      </Card>
    </AppLayout>
  );
}
